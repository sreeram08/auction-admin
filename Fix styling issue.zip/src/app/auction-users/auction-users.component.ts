import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-auction-users',
  templateUrl: './auction-users.component.html',
  styleUrls: ['./auction-users.component.css']
})
export class AuctionUsersComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
